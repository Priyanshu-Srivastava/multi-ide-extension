# Omni IDE - Unified (JetBrains)

Single global Omni JetBrains sidecar bundle with team features grouped by team names.

IDE: jetbrains

## Team Feature Groups

- team-a: omni-jetbrains-sidecar-team-a (manifest version 1.0.2)
- team-b: omni-jetbrains-sidecar-team-b (manifest version 1.0.2)
- team-c: omni-jetbrains-sidecar-team-c (manifest version 1.0.2)
- team-d: omni-jetbrains-sidecar-team-d (manifest version 1.0.2)

This is a single global extension pack; team versions are managed in each team manifest.
The jetbrains marketplace installs the latest published versions for the listed team extensions.
